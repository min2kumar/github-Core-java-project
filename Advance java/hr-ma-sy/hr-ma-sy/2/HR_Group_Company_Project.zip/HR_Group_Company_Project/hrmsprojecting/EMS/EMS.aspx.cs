using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace hrmsprojecting
{
	/// <summary>
	/// Summary description for EmployeeCommunication.
	/// </summary>
	public partial class EmployeeCommunication : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label6;

        SqlConnection con = new SqlConnection("Data Source=APTTECH5;Initial Catalog=HRGroup;Integrated Security=True");
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			txtFrom.Text= Convert.ToString(Session["UserId"]);
			if(txtFrom.Text=="admin")
			{
				lblFromName.Text ="HR";
				lblFromName.Visible = true;
				HyperLink2.Visible=true;
			}
			else
			{
				con.Open();
				SqlCommand cmd1 = new SqlCommand();
				cmd1.CommandText="Select EmployeeName From Employee where EmployeeId='"+ txtFrom.Text +"'";
				cmd1.Connection=con;
				lblFromName.Text =Convert.ToString(cmd1.ExecuteScalar());
				lblFromName.Visible = true;
				con.Close();
			}
			if (!Page.IsPostBack)
			{
				con.Open(); 
				SqlCommand cmd = new SqlCommand("select EmployeeId from Employee");
				cmd.Connection = con;
				SqlDataReader dr;
				dr = cmd.ExecuteReader();
				DrTo.Items.Add("Select");
				while (dr.Read())
				{
					DrTo.Items.Add(Convert.ToString(dr[0]));
				}
				con.Close();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void Button1_Click(object sender, System.EventArgs e)
		{
			string date=DateTime.Now.ToShortDateString();
			string userid = txtFrom.Text;			
			  if (DrTo.SelectedItem.Text == "Select")
				{
					Label5.Text = "Select User Id";	
					Label5.Visible=true;
				}
			else
			{
				HyperLink1.Visible=true;
				con.Open();
				SqlCommand cmd = new SqlCommand();
				cmd.CommandText="insert into Communication values('"+ userid +"','"+ lblFromName.Text +"','"+ DrTo.SelectedItem.Text +"','"+ lblToName.Text +"','"+ txtSubject.Text +"','"+ txtMessage.Text +"','"+ date +"')";
				cmd.Connection=con;
				cmd.ExecuteNonQuery();
				con.Close();
				txtFrom.Visible=false;
				DrTo.Visible=false;
				txtSubject.Visible=false;
				txtMessage.Visible=false;
				Label1.Visible=false;
				Label2.Visible=false;
				Label3.Visible=false;
				Label4.Visible=false;
				Button1.Visible=false;
				Button2.Visible=false;	
				lblFromName.Visible=false;
				lblToName.Visible=false;
				Label7.Text="Message Sent Successfully.....";
				Label7.Visible=true;
				
							
			}	
			
		}

		protected void DrTo_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			con.Open();
			SqlCommand cmd1 = new SqlCommand();
			cmd1.CommandText="Select EmployeeName From Employee where EmployeeId='"+ DrTo.SelectedItem.Text +"'";
			cmd1.Connection=con;
			lblToName.Text =Convert.ToString(cmd1.ExecuteScalar());
			lblToName.Visible = true;
			con.Close();
		}

		protected void Button2_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("EMS.aspx");

		}
	}
}