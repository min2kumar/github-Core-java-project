using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace HRMS
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public partial class WebForm1 : System.Web.UI.Page
	{

        SqlConnection con = new SqlConnection("Data Source=APTTECH5;Initial Catalog=HRGroup;Integrated Security=True");

		protected void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void Registration_education_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		protected void Registration_insert_ServerClick(object sender, System.EventArgs e)
		{
			
			string a,c,d,h,i,j,k ;
			DateTime g;
			long f;

			a=Registration_first_name.Text + " " + Registration_last_name.Text;
			c=Registration_email.Text;
			d=Registration_address1.Text + "," + Registration_address2.Text;
			
			f= Convert.ToInt64(Registration_phone_day.Text);
			g=Convert.ToDateTime(Registration_dob_m.SelectedItem + "/" + Registration_dob_d.SelectedItem + "/" + Registration_dob_y.SelectedItem);
			h=Convert.ToString(Registration_gender.SelectedItem);
			i=Convert.ToString(Registration_education.SelectedItem);
			j=Convert.ToString(Registration_domain.SelectedItem);
			k=Registration_notes.Text;

			con.Open();

			SqlCommand cmd = new SqlCommand();
			cmd.CommandText= "select Top 1 cno from candidatesdetails order by cno desc";
			cmd.Connection=con;
			int ccc;
			ccc=Convert.ToInt32(cmd.ExecuteScalar());
			Session["cno"] = ccc+1;
			Session["Domain"] = Convert.ToString(Registration_domain.SelectedItem);
		
          	cmd.CommandText="insert into candidatesdetails(Firstname,email,address,mobno,dob,gender,education,domain,notes) values(' " + a + " ',' " + c + " ',' " + d + " '," + f + ",' " + g + " ',' " + h + " ',' " + i + " ',' " + j + " ',' " + k + " ')";
			cmd.Connection=con;
			cmd.ExecuteNonQuery();
			Response.Redirect("writeexam.aspx");

			con.Close();

		}

		protected void Registration_address2_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		protected void Registration_cancel_ServerClick(object sender, System.EventArgs e)
		{
			
			Registration_first_name.Text = "";
			Registration_last_name.Text= "";
			Registration_email.Text="";
			Registration_address1.Text="";
			Registration_address2.Text="";
			Registration_phone_day.Text="";
			Registration_notes.Text="";

		}
	}
}
