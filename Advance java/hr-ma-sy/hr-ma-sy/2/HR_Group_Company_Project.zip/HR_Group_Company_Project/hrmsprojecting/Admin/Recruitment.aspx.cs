using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
namespace WebApplication20
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public partial class WebForm1 : System.Web.UI.Page
	{

        SqlConnection con = new SqlConnection("Data Source=APTTECH5;Initial Catalog=HRGroup;Integrated Security=True;");
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			DateTime rightNow = DateTime.Now;
			TextBox1.Text=String.Format("{0:d}", rightNow);
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void Button1_Click(object sender, System.EventArgs e)
		{
			
			string str;
			DateTime  g;
			string domain;
			domain=jobpostingdomain.SelectedItem.Text;			
			g=Convert.ToDateTime(L_m.SelectedItem+"/"+L_d.SelectedItem+"/"+L_y.SelectedItem);
			con.Open();
			str="insert into jobposting values('"+TextBox1.Text+"','"+TextBox2.Text+"','"+jobpostingdesc.SelectedItem.Text+"','"+TextBox3.Text+"','"+g+"','"+TextBox4.Text+"','"+domain+"')"; 
			SqlCommand cmd=new SqlCommand(str,con);
			cmd.ExecuteNonQuery();
			Label8.Text="Job Posting Made Successfully...";
			Label8.Visible=true;
			TextBox2.Text="";
            TextBox3.Text="";
			TextBox4.Text="";
			con.Close();

		
		}

		protected void Button2_Click(object sender, System.EventArgs e)
		{
	
		}


        protected void L_y_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
}
}
