using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;


namespace HRMS
{
	/// <summary>
	/// Summary description for WebForm3.
	/// </summary>
	public partial class WebForm3 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button Button1;

        SqlConnection con = new SqlConnection("Data Source=APTTECH5;Initial Catalog=HRGroup;Integrated Security=True;");
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ImageButton1.Click += new System.Web.UI.ImageClickEventHandler(this.ImageButton1_Click);

		}
		#endregion

	 		
		private void Button2_Click(object sender, System.EventArgs e)
		{
		
		}

		private void ImageButton1_Click(object sender, System.Web.UI.ImageClickEventArgs e)
		{
			SqlCommand cmd;
			con.Open();
			string un;
			string pw;
			un =Textbox1.Text;
			pw = TextBox2.Text;
			cmd = new SqlCommand("Select count(*) From Admin where username='" + un + "' and passwords='" + pw + "'", con);
			if(Convert.ToInt32(cmd.ExecuteScalar())==0)

			{
				Label3.Text = "Login Failed...";
				Label3.Visible=true;
			}
			else
			{
				con.Close();
				Session["UserId"] = un;
				Session["Password"] = pw;
				Session["Usertype"] = "Admin";
				Response.Redirect("../Admin/AdminOptions.aspx");
			}
				


		

		}
        protected void ImageButton1_Click1(object sender, ImageClickEventArgs e)
        {

        }
}
}
