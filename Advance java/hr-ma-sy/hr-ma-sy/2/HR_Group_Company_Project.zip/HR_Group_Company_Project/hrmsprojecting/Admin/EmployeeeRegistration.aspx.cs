using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace SuganyaModule
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public partial class WebForm1 : System.Web.UI.Page
	{

        SqlConnection con = new SqlConnection("Data Source=APTTECH5;Initial Catalog=HRGroup;Integrated Security=True");
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		

		protected void Submit_Click(object sender, System.EventArgs e)
		{
			string optLoan,optDocument,optAward,optExtra,optMedical,optGender;
			DateTime DojDate,DobDate;
			//Date of Birth and Date of Join
			DobDate=Convert.ToDateTime(drDobMonth.SelectedItem + "/" + drDobDate.SelectedItem + "/" + drDobYear.SelectedItem);
			DojDate=Convert.ToDateTime(drDojMonth.SelectedItem + "/" + drDojDate.SelectedItem + "/" + drDojYear.SelectedItem);
						
			//Gender
			if (rb_Gender_Male.Checked==true)
				optGender="M";
			else
				optGender="F";
						
			//Loan
			if (rb_Loan_Yes.Checked==true)
			optLoan="Y";
			else
			optLoan="N";
			
			//Document
			if (rb_Document_Yes.Checked==true)
				optDocument="Y";
			else
				optDocument="N";
			
			//ExtraCurriculam
			if (rb_extra_yes.Checked==true)
				optExtra="Y";
			else
				optExtra="N";
			
			//ClubMembership
//			if (rb_club_yes.Checked==true)
//				optClub="Y";
//			else
//				optClub="N";
			
			//Awards
			if (rb_awards_yes.Checked==true)
				optAward="Y";
			else
				optAward="N";
			
			//Medical
			if (rb_Medical_yes.Checked==true)
				optMedical="Y";
			else
				optMedical="N";
		
			if (drDesignation.SelectedItem.Text == "Select"  || drQualification.SelectedItem.Text == "Select"  || drExperience.SelectedItem.Text == "Select")
			{
				Label1.Text = "Select The Missed Options";
			}
			else 
			{
				
				con.Open();
				SqlCommand cmd= new SqlCommand();
				cmd.CommandText = "insert into Employee values('"+ txtEmployeeId.Text +"','"+ txtEmployeeName.Text +"','"+ optGender +"','"+ drDesignation.SelectedItem.Text +"','"+ drQualification.SelectedItem.Text +"','"+ drExperience.SelectedItem.Text +"','"+ DobDate +"','"+ DojDate +"','"+txtContactPerson.Text+"','"+ txtTemporaryAddress.Text +"','"+ txtPermanentAddress.Text +"',"+ txtMobile.Text +",'"+ optLoan +"','"+ txtLoanDescription.Text +"','"+ optDocument +"','"+ txtDoumentDescription.Text +"','"+ optExtra +"','"+ txtExtraDescription.Text +"','"+ optAward +"','"+ txtAwardDescription.Text +"','"+ optMedical +"','"+ txtMedicalDescription.Text +"')";
				cmd.Connection=con;
				cmd.ExecuteNonQuery();
				Label1.Text="Registered Sucessfully...";
				Label1.Visible=true;
				con.Close();
			}
			
		}

		protected void Cancel_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("EmployeeeRegistration.aspx");
		}

		protected void drQualification_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		protected void rb_Loan_Yes_CheckedChanged(object sender, System.EventArgs e)
		{
			rb_Loan_No.Enabled=false;
			rb_Loan_No.Checked=false;

		}

		protected void rb_Document_Yes_CheckedChanged(object sender, System.EventArgs e)
		{
			rb_Document_No.Enabled=false;
			rb_Document_No.Checked=false;
		
		}

		protected void rb_extra_yes_CheckedChanged(object sender, System.EventArgs e)
		{
			rb_extra_No.Enabled=false;
			rb_extra_No.Checked=false;

		}

		protected void rb_club_yes_CheckedChanged(object sender, System.EventArgs e)
		{
			rb_club_No.Enabled=false;
			rb_club_No.Checked=false;
		}

		protected void rb_awards_yes_CheckedChanged(object sender, System.EventArgs e)
		{
			rb_awards_no.Enabled=false;
			rb_awards_no.Checked=false;
		}

		protected void rb_Medical_yes_CheckedChanged(object sender, System.EventArgs e)
		{
			rb_Medical_no.Enabled=false;
			rb_Medical_no.Checked=false;
		}

		protected void rb_Loan_No_CheckedChanged(object sender, System.EventArgs e)
		{
			rb_Loan_Yes.Enabled=false;
			rb_Loan_Yes.Checked=false;
		}

		protected void rb_Document_No_CheckedChanged(object sender, System.EventArgs e)
		{
			rb_Document_Yes.Enabled=false;
			rb_Document_Yes.Checked=false;
		}

		protected void rb_extra_No_CheckedChanged(object sender, System.EventArgs e)
		{
			rb_extra_yes.Enabled=false;
			rb_extra_yes.Checked=false;
		}

		protected void rb_club_No_CheckedChanged(object sender, System.EventArgs e)
		{
			
			rb_club_yes.Enabled=false;
			rb_club_yes.Checked=false;
		}

		protected void rb_awards_no_CheckedChanged(object sender, System.EventArgs e)
		{
			rb_awards_yes.Enabled=false;
			rb_awards_yes.Checked=false;
		}

		private void rb_Medical_no_CheckedChanged(object sender, System.EventArgs e)
		{
			rb_Medical_yes.Enabled=false;
			rb_Medical_yes.Checked=false;
		}

		private void RadioButton1_CheckedChanged(object sender, System.EventArgs e)
		{
			rb_Loan_No.Enabled=false;
			rb_Loan_No.Checked=false;

		}

		protected void rb_Gender_Male_CheckedChanged(object sender, System.EventArgs e)
		{
			rb_Gender_Male.Enabled=false;
			rb_Gender_Female.Checked=false;
		
		}

		protected void drDojDate_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		protected void drDojYear_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		   
		}

	
		

	
	}
}
