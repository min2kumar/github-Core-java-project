using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace hrmsprojecting
{
	/// <summary>
	/// Summary description for ViewEmployeeProfile.
	/// </summary>
	public partial class ViewEmployeeProfile : System.Web.UI.Page
	{

        SqlConnection con = new SqlConnection("Data Source=APTTECH5;Initial Catalog=HRGroup;Integrated Security=True;");

		protected void Page_Load(object sender, System.EventArgs e)
		{
			con.Open();
			SqlCommand cmd = new SqlCommand("select EmployeeId from Employee");
			cmd.Connection = con;
			SqlDataReader dr;
			dr = cmd.ExecuteReader();
			while (dr.Read())
			{
				DropDownList1.Items.Add(Convert.ToString(dr[0]));
			}
			con.Close();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void DropDownList1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			DropDownList1.Visible = false;
			Label1.Visible = false;
			con.Open();
			DataSet ds = new DataSet();
			string eid = DropDownList1.SelectedItem.Text;
			SqlDataAdapter adp = new SqlDataAdapter("select * from Employee where EmployeeId='"+ eid +"' ",con);
			adp.Fill(ds);
			DataList1.DataSource = ds;
			DataList1.DataBind();
			con.Close();
			Button1.Visible=true;
		}

		protected void DataList1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		protected void Button1_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("ViewEmployeeProfile.aspx");
		}
	}
}
