using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace hrmsprojecting
{
	/// <summary>
	/// Summary description for Salary.
	/// </summary>
	public partial class Salary : System.Web.UI.Page
	{

        SqlConnection con = new SqlConnection("Data Source=APTTECH5;Initial Catalog=HRGroup;Integrated Security=True;");
		int TotalWorkDays,TotalLeaveDays;
		double LossOfPay,OTPay;
		double NetPay;
		string CurrentDate;
		protected void Page_Load(object sender, System.EventArgs e)
        {
			CurrentDate=DateTime.Now.ToShortDateString();
			lblDate.Text=Convert.ToString(CurrentDate);
			
			if (!Page.IsPostBack)
			{
				con.Open(); 
				SqlCommand cmd = new SqlCommand("select EmployeeId from Employee");
				cmd.Connection = con;
				SqlDataReader dr;
				dr = cmd.ExecuteReader();
				drEmployeeId.Items.Add("Select");
				while (dr.Read())
				{
					drEmployeeId.Items.Add(Convert.ToString(dr[0]));
				}
				con.Close();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void TextBox3_TextChanged(object sender, System.EventArgs e)
		{
			
		}

		protected void drEmployeeId_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			con.Open(); 
			string eid = drEmployeeId.SelectedItem.Text;
			SqlCommand cmd = new SqlCommand("select EmployeeName,Designation from Employee where EmployeeId = '"+ eid +"'");
			cmd.Connection = con;
			SqlDataReader dr;
			dr = cmd.ExecuteReader();
			if (dr.Read())
			{
				txtEmployeeName.Text = Convert.ToString(dr[0]);
				txtDesignation.Text = Convert.ToString(dr[1]);

			}
			
			con.Close();
	

		}

		protected void btnSave_Click(object sender, System.EventArgs e)
		{
			if (drEmployeeId.SelectedItem.Text == "Select")
			{
				lblMessage.Text = "Select The Missed Options";
			}
//			else if(txtBasicPay.Text="" && txtHRA.Text="" && txtMedicalAllowance.Text="")
//			{
//				lblMessage.Text="Click The View Button";
//			}
			else 
			{
				
				con.Open();
				SqlCommand cmd= new SqlCommand();
				cmd.CommandText = "insert into SalaryDetails values("+ lblReciptNo.Text +",'"+ lblDate.Text +"','"+ drEmployeeId.SelectedItem.Text +"',"+ txtBasicPay.Text +","+ txtHRA.Text +","+ txtMedicalAllowance.Text +","+ txtConvayence.Text +","+ txtSpecialAllowance.Text +","+ txtIncentivies.Text +","+ txtOthersEarnings.Text +",'"+ txtEarOtherDescription.Text +"',"+ txtProffesionalTax.Text +","+ txtPF.Text +","+ txtAdvance.Text +","+ txtCanteen.Text +","+ txtLoan.Text +","+ txtOthersDeduction.Text +",'"+ txtDedOthersDescription.Text +"',"+ txtTotalEarnings.Text +","+ txtTotalDeduction.Text +","+ txtNetPay.Text +")";
			//															1						2					3									4						5				6							7						8							9						10							11								12							13					14				15				  16							17									18							19						20					21
				cmd.Connection=con;
				cmd.ExecuteNonQuery();
				lblMessage.Text="Entry Made Sucessfully...";
				con.Close();
			}
		}
		
		protected void ViewSalaryStructure_Click(object sender, System.EventArgs e)
		{

				//To view The Salary Structure From The Salary Table InsteadOf The Designation And Employeeid
				con.Open(); 
				string eDesignation = txtDesignation.Text;
				SqlCommand cmd = new SqlCommand("Select * from SalaryStructure where Designation IN (select Designation from Employee where Designation='"+txtDesignation.Text+"')");
				cmd.Connection = con;
				SqlDataReader dr;
				dr=cmd.ExecuteReader();
				if(dr.Read())
				{
					txtBasicPay.Text=Convert.ToString(dr[2]);
					txtHRA.Text=Convert.ToString(dr[3]);
					txtMedicalAllowance.Text=Convert.ToString(dr[4]);
					txtConvayence.Text=Convert.ToString(dr[5]);
					txtProffesionalTax.Text=Convert.ToString(dr[6]);
					txtPF.Text=Convert.ToString(dr[7]);
				}
				con.Close();	
					txtBasicPay.Enabled=false;
					txtHRA.Enabled=false;
					txtMedicalAllowance.Enabled=false;
					txtConvayence.Enabled=false;
					txtProffesionalTax.Enabled=false;
					txtPF.Enabled=false;
			}

		protected void txtEarOtherDescription_TextChanged(object sender, System.EventArgs e)
        {
			if (txtConvayence.Text=="" ) 
			{
				txtConvayence.Text=Convert.ToString("0");
			}
			if(txtSpecialAllowance.Text=="" )
			{
				txtSpecialAllowance.Text=Convert.ToString("0"); 
			}
			if(txtIncentivies.Text=="")
			{
				txtIncentivies.Text=Convert.ToString("0"); 
			}
			if(txtOthersEarnings.Text=="")
			{
				txtOthersEarnings.Text=Convert.ToString("0"); 
			}
			int TotalEarnings=Convert.ToInt32(txtBasicPay.Text)+Convert.ToInt32(txtConvayence.Text)+Convert.ToInt32(txtHRA.Text)+Convert.ToInt32(txtMedicalAllowance.Text)+Convert.ToInt32(txtSpecialAllowance.Text)+Convert.ToInt32(txtOthersEarnings.Text);
			txtTotalEarnings.Text=Convert.ToString(TotalEarnings);
			
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
		
		}

		protected void txtHRA_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		protected void txtDesignation_TextChanged(object sender, System.EventArgs e)
		{
		
		}



		protected void txtTotalDeduction_TextChanged(object sender, System.EventArgs e)
		{
			
		}

		protected void txtNetPay_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		protected void DropDownList1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			ViewWdays.Enabled=true;
			
			string SelectedMonth= drMonth.SelectedItem.Text;
			if(SelectedMonth=="January" || SelectedMonth=="March" || SelectedMonth=="July" || SelectedMonth=="August" || SelectedMonth == "October" ||SelectedMonth=="December")
			{
				txtTotalDays.Text=Convert.ToString("31");
			}
			else if (SelectedMonth=="February")
			{
				txtTotalDays.Text=Convert.ToString("28");
			}
			else
			{
				txtTotalDays.Text=Convert.ToString("30");
			}
		}

		public void ViewWdays_Click(object sender, System.EventArgs e)
		{
			
			double Pay = Convert.ToDouble(txtTotalEarnings.Text) - Convert.ToDouble(txtTotalDeduction.Text);
			
			con.Open(); 
			SqlCommand cmd = new SqlCommand("select count(Status) as AbsentDays from Attendence where Status='P' and EmployeeId='"+drEmployeeId.SelectedItem.Text+"'");
			cmd.Connection = con;
//			int TotalWorkDays,TotalLeaveDays,LossOfPay,OTPay;
			TotalWorkDays=Convert.ToInt32(cmd.ExecuteScalar());
			con.Close();
			TotalLeaveDays=Convert.ToInt32(txtTotalDays.Text)-TotalWorkDays;
			txtWorkDays.Text=Convert.ToString(TotalWorkDays);
			txtLeaveDays.Text=Convert.ToString(TotalLeaveDays);
			if ((Convert.ToDouble(TotalLeaveDays))>1)
			{
				LossOfPay=Convert.ToDouble((Convert.ToDouble(Pay)/30)*TotalLeaveDays);
				NetPay=Pay-LossOfPay;
				txtNetPay.Text=Convert.ToString(NetPay);
				
			}
			if((Convert.ToInt32(TotalWorkDays))>30)
			{
				OTPay= Convert.ToDouble((Convert.ToDouble(Pay)/30)*TotalLeaveDays);
				NetPay=Pay+OTPay;
				txtNetPay.Text=Convert.ToString(NetPay);

			}

		}

		protected void txtTotalDays_TextChanged(object sender, System.EventArgs e)
		{
			
		}

		protected void txtDedOthersDescription_TextChanged(object sender, System.EventArgs e)
		{
			if (txtProffesionalTax.Text=="")
			{
				txtProffesionalTax.Text=Convert.ToString("0");
			}
			if(txtPF.Text=="")
			{
				txtPF.Text=Convert.ToString("0");
			}
			if(txtAdvance.Text=="")
			{
				txtAdvance.Text=Convert.ToString("0");
			}
			if(txtCanteen.Text=="")
			{
				txtCanteen.Text=Convert.ToString("0");
			}
			if(txtLoan.Text=="")
			{
				txtLoan.Text=Convert.ToString("0");
			}
			if(txtOthersDeduction.Text=="")
			{
				txtOthersDeduction.Text=Convert.ToString("0");
			}
			int TotalDeduction=Convert.ToInt32(txtProffesionalTax.Text)+Convert.ToInt32(txtPF.Text)+Convert.ToInt32(txtAdvance.Text)+Convert.ToInt32(txtLoan.Text)+Convert.ToInt32(txtCanteen.Text)+Convert.ToInt32(txtOthersDeduction.Text);
			txtTotalDeduction.Text=Convert.ToString(TotalDeduction);
			
		}

//		private void ViewWdays_Click(object sender, System.EventArgs e)
//		{
//		
//
//			
//		}
		}

		//private void txtTotalDays_TextChanged(object sender, System.EventArgs e)
		//{
		
		//}
	
}
