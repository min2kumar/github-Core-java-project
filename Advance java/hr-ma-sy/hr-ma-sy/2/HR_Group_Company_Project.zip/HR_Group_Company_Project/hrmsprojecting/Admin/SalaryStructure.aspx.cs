using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace hrmsprojecting
{
	/// <summary>
	/// Summary description for SalaryStructure.
	/// </summary>
	public partial class SalaryStructure : System.Web.UI.Page
	{

        SqlConnection con = new SqlConnection("Data Source=APTTECH5;Initial Catalog=HRGroup;Integrated Security=True");

		protected void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void Button1_Click(object sender, System.EventArgs e)
		{
			
			if(drDesignation.SelectedItem.Text=="Select")
			{
				lblvalidation.Text="Select Designation";
				lblvalidation.Visible=true;
			}
			else
			{			
				con.Open();
				SqlCommand cmd = new SqlCommand();
				cmd.CommandText="insert into SalaryStructure values('"+ drDesignation.SelectedItem.Text +"',"+ txt_basicpay.Text +","+ txt_HRA.Text +","+ txt_MedicalAlv.Text +","+ txt_Convayence.Text +","+ txt_ProffTax.Text +","+ txt_PF.Text +")";
				cmd.Connection=con;
				cmd.ExecuteNonQuery();
				lbl_write.Text="Salary Structure Made Successfully...";
				lbl_write.Visible=true;
				con.Close();
				txt_basicpay.Text="";
				txt_HRA.Text="";
				txt_MedicalAlv.Text="";
				txt_Convayence.Text="";
				txt_ProffTax.Text="";
				txt_PF.Text="";
				
			}

		}

		protected void Button2_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("SalaryStructure.aspx");
		}
	}
}
