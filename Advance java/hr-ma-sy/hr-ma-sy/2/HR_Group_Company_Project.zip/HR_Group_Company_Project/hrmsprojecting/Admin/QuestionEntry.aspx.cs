using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient ;


namespace hrmsprojecting
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public partial class WebForm1 : System.Web.UI.Page
	{

        SqlConnection con = new SqlConnection("Data Source=APTTECH5;Initial Catalog=HRGroup;Integrated Security=True");
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
				
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		

		protected void Button1_Click(object sender, System.EventArgs e)
		{
		    
			if(DropDownList1.SelectedItem.Text=="Select")
			{
				Label7.Text="Choose Domain";
				return;

			}

			if (TextBox1.Text == "" | Textbox2.Text == "" | Textbox3.Text == "" | Textbox4.Text == "" | Textbox5.Text == "" | Textbox6.Text == "" )

			{
				Label7.Text = "Invalid Data";
				return; 
			}

			int i;
			int j;
			string[] a1 = new string[5];
			string ca;
			a1[0] = Textbox2.Text;
			a1[1] = Textbox3.Text;
			a1[2] = Textbox4.Text;
			a1[3] = Textbox5.Text;
			ca = Textbox6.Text;
			for (i = 0; i <= 2; i++) 
			{
				for (j = i + 1; j <= 3; j++) 
				{
					if (a1[i].Equals(a1[j]))
					{
						Label7.Text = "Duplication occurs";
						return; 
					}
				}
			}

			if (!(ca == a1[0] | ca == a1[1] | ca == a1[2] | ca == a1[3]))
			{
				Label7.Text = "Check Correct Answer";
				return;
			}

			
			if (DropDownList1.SelectedItem.Text == "Select id")
			{
				Label7.Text = "Select Job Id";
				return; 
			}

			string drop;
			drop=DropDownList1.SelectedItem.Text ;
			
			string str;
			con.Open();
			str="insert into question values ('"+ drop +"','"+ TextBox1.Text +"','"+ Textbox2.Text +"','"+ Textbox3.Text +"','"+ Textbox4.Text +"','"+ Textbox5.Text +"','"+ Textbox6.Text +"',"+ Label2.Text +")"; 
			SqlCommand cmd=new SqlCommand();
			cmd=new SqlCommand(str,con);
			cmd.ExecuteNonQuery();
			Label7.Text = "Question Entered Successfully...";
			//Label2.Text = Conversion.Val(Label2.Text) + 1;
			TextBox1.Text = "";
			Textbox2.Text = "";
			Textbox3.Text = "";
			Textbox4.Text = "";
			Textbox5.Text = "";
			Textbox6.Text = "";
		
			string s;
			s= DropDownList1.SelectedItem.Text;
			cmd = new SqlCommand("select count(*) from question where domain ='"+ s +"'");
			cmd.Connection=con;
			string a;
			a=Convert.ToString(cmd.ExecuteScalar());
			Label2.Text =Convert.ToString(Convert.ToInt32(a)+1); 
            Label2.Visible=true;                        
			con.Close();

		}

		protected void DropDownList1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
            if (Page.IsPostBack==true)
			{
				
				con.Open();
				string s;
				s= DropDownList1.SelectedItem.Text;
				SqlCommand cmd = new SqlCommand("select count(*) from question where domain ='"+ s +"'");
				cmd.Connection=con;
				string a;
				a=Convert.ToString(cmd.ExecuteScalar());
                Label2.Text =Convert.ToString(Convert.ToInt32(a)+1); 
                Label2.Visible=true;                    
				con.Close();
			}

		
		}
	}
}
