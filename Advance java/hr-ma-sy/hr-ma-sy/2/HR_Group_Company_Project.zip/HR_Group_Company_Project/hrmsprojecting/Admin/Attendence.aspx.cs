using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace hrmsprojecting
{
	/// <summary>
	/// Summary description for WebForm3.
	/// </summary>
	public partial class Attendence : System.Web.UI.Page
	{
		protected System.Web.UI.HtmlControls.HtmlGenericControl lb1;

        SqlConnection con = new SqlConnection("Data Source=APTTECH5;Initial Catalog=HRGroup;Integrated Security=True");
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			
			if (!Page.IsPostBack)
			{
				con.Open(); 
				SqlCommand cmd = new SqlCommand("select EmployeeId from Employee");
				cmd.Connection = con;
				SqlDataReader dr;
				dr = cmd.ExecuteReader();
				drEmployeeid.Items.Add("Select");
				
				while (dr.Read())
				{
					drEmployeeid.Items.Add(Convert.ToString(dr[0]));
				}
				con.Close();
				drShift.Items.Add("Select");
				drShift.Items.Add("DayShift");
				drShift.Items.Add("NightShift");
				drShift.Items.Add("Flexible");
			}
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		private void Submit_Click(object sender, System.EventArgs e)
		{
			
			
		}
		public void ClearPage()
		{
			
		}
		protected void Button1_Click(object sender, System.EventArgs e)
		{
			string CurrentDate,CurrentTime;
			string SignIn="null";
			string SignOut="null";
			string Status="null";
			//int t;
			CurrentDate=DateTime.Now.ToShortDateString();
			
			//Time
			CurrentTime=DateTime.Now.ToShortTimeString();
			
//			//To enabeled the rbSignin and SignOut Button
//			if(HRMSTime=="12:00am" && HRMSTime=="12:00pm")
//			{
//				rbSignin.Enabled=true;
//				rbSignOut.Enabled=false;
//			}
//			else
//			
//			{
//				rbSignin.Enabled=false;
//				rbSignOut.Enabled=true;
//			}

			//			To sigin and SignOut
			if (rbSignin.Checked ==true )
			{
				SignIn=DateTime.Now.ToShortTimeString();
			
				Status="P";
				
			}
			if(rbSignOut.Checked==true)
			{
				SignOut=DateTime.Now.ToShortTimeString();
				Status="P";
				
				
			}
			if (rbSignin.Checked ==false && rbSignOut.Checked == false ) 
			{
				Status="A";
			}
			
			//Validation for Dropdown Controls 
			//To Select the proper Item
			if (drEmployeeid.SelectedItem.Text=="Select")
			{
				Label1.Text = "Select The EmployeeId";
				return;
			}
			if(drShift.SelectedItem.Text=="Select")
			{
				Label2.Text="Select The Shift";
				return;
			}	
					
			//To store the data into Database		
			con.Open();
			SqlCommand cmd= new SqlCommand();
			cmd.CommandText = "insert into Attendence values('"+ drEmployeeid.SelectedItem.Text +"','"+ CurrentDate +"','"+CurrentTime+"','"+ drShift.SelectedItem.Text +"','"+ SignIn +"','"+ SignOut +"','"+Status+"')";
			cmd.Connection=con;
			cmd.ExecuteNonQuery();
			Label3.Text="Attendence Entry Made Sucessfully...";
			con.Close();
			rbSignin.Checked=false;
			rbSignOut.Checked=false;
		}

		protected void rbSignin_CheckedChanged(object sender, System.EventArgs e)
		{
			rbSignOut.Enabled=false;
			rbSignOut.Checked=false;
		}

		protected void rbSignOut_CheckedChanged(object sender, System.EventArgs e)
		{
			rbSignin.Enabled=false;
			rbSignin.Checked=false;
		}

		protected void drEmployeeid_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				rbSignin.Enabled=true;
				rbSignOut.Enabled=true;
				Label3.Text="";
				
			}
			
		}

		private void LinkButton1_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("../Admin/AdminOptions.aspx");
		}

		
	}
}
