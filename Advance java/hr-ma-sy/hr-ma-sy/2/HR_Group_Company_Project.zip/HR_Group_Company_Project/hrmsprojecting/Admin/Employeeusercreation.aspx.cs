using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;


namespace HRMS
{
	/// <summary>
	/// Summary description for WebForm2.
	/// </summary>
	public partial class WebForm2 : System.Web.UI.Page
	{

        SqlConnection con = new SqlConnection("Data Source=APTTECH5;Initial Catalog=HRGroup;Integrated Security=True;");
        	
	
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack)
			{
				con.Open(); 
				SqlCommand cmd = new SqlCommand("select EmployeeId from Employee");
				cmd.Connection = con;
				SqlDataReader dr;
				dr = cmd.ExecuteReader();
				DropDownList1.Items.Add("Select");
				while (dr.Read())
				{
					DropDownList1.Items.Add(Convert.ToString(dr[0]));
				}
				con.Close();
			}
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void Button1_Click(object sender, System.EventArgs e)
		{
			string userid = DropDownList1.SelectedItem.Text;			
			string utype="N";
			if (userid == "Select")
			{
				Label3.Text = "Select User Id";	
				Label3.Visible=true;
			}
			else
			{
				con.Open();
				SqlCommand cmd = new SqlCommand();
				cmd.CommandText="select count(*) from EmployeeLogin where UserId='"+ userid +"'";
				cmd.Connection=con;
				if(Convert.ToInt32(cmd.ExecuteScalar())==0)
				{
					cmd.CommandText="insert into EmployeeLogin values('"+ userid +"' , '"+ TextBox2.Text +"', '"+ utype +"')";
					cmd.Connection=con;
					cmd.ExecuteNonQuery();
					Label4.Text="User Id Created";
					Label4.Visible=true;
					con.Close();
					TextBox2.Text = "";
				}
				else 
				{
					Label4.Text="UserID Already Exists";
					Label4.Visible=true;
				}
			}
				
				
		}

		protected void Button2_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("Employeeusercreation.aspx");
		}

		protected void DropDownList1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}
	}
}
