using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace hrmsprojecting
{
	/// <summary>
	/// Summary description for WebForm2.
	/// </summary>
	public partial class WebForm2 : System.Web.UI.Page
	{
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			if (!Page.IsPostBack)
			{

				intPageSize.Text = "5";
				intCurrIndex.Text = "0"; 			
				DataBinds(); 
			
			}
	

		}
		public void  DataBinds()
		{
			
			//string to1 = Convert.ToString(Session["UserId"]);
            SqlConnection objConn = new SqlConnection("Data Source=APTTECH5;Initial Catalog=HRGroup;Integrated Security=True;");
			SqlDataAdapter objDA = new SqlDataAdapter("select * from jobposting",objConn);
			DataSet objDS = new DataSet();

			if (!Page.IsPostBack )
			{
				objDA.Fill(objDS);
				intRecordCount.Text =Convert.ToString(objDS.Tables[0].Rows.Count);
				objDS = null;
				objDS = new DataSet();
			}

			objDA.Fill(objDS, Convert.ToInt16(intCurrIndex.Text), Convert.ToInt16(intPageSize.Text), "Sales");

			DataList1.DataSource = objDS.Tables[0].DefaultView;
			DataList1.DataBind();
			objConn.Close();
			PrintStatus();
		}

		public void ShowFirst(object s, EventArgs e)
		{
			intCurrIndex.Text = "0";
			DataBinds();
		}


		public void ShowPrevious(object s, EventArgs e)
		{
			int a=Convert.ToInt16(intCurrIndex.Text);
			int b=Convert.ToInt16(intPageSize.Text);
			intCurrIndex.Text = Convert.ToString(a-b);

			if ( Convert.ToInt16(intCurrIndex.Text) < 0)
			{
				intCurrIndex.Text = "0";
			}
			DataBinds();
		}

		public void ShowNext(object s, EventArgs e)
		{
			if ( Convert.ToInt16( intCurrIndex.Text) + 1 < Convert.ToInt16(intRecordCount.Text))
			{
				 
				   
				intCurrIndex.Text =  Convert.ToString( Convert.ToInt16(intCurrIndex.Text) + Convert.ToInt16(intPageSize.Text));
			}
			DataBinds();
		}

		public void ShowLast(object s, EventArgs e)
		{
			int tmpInt;

			tmpInt = Convert.ToInt16(intRecordCount.Text) % Convert.ToInt16(intPageSize.Text);
			if (tmpInt > 0)
			{
				intCurrIndex.Text =  Convert.ToString((Convert.ToInt16(intRecordCount.Text) - tmpInt));
			}
			else
			{
				intCurrIndex.Text =  Convert.ToString (Convert.ToInt16( intRecordCount.Text) - Convert.ToInt16( intPageSize.Text));
			}
			DataBinds();
		}

		private void PrintStatus()
		{
			lblStatus.Text = "Total Records:<b>" + intRecordCount.Text;
			lblStatus.Text += "</b> - Showing Page:<b> ";
			lblStatus.Text +=  Convert.ToString (Convert.ToInt16(intCurrIndex.Text) / Convert.ToInt16(intPageSize.Text + 1));
			lblStatus.Text += "</b> of <b>";

			if (( Convert.ToInt16(intRecordCount.Text) % Convert.ToInt16( intPageSize.Text)) > 0)
			{
				lblStatus.Text += Convert.ToString( Convert.ToInt16(intRecordCount.Text) /Convert.ToInt16( intPageSize.Text + 1));
			}
			else
			{
				lblStatus.Text += Convert.ToString (Convert.ToInt16(intRecordCount.Text) / Convert.ToInt16(intPageSize.Text));
			}
			lblStatus.Text += "</b>";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

	
	}
}
