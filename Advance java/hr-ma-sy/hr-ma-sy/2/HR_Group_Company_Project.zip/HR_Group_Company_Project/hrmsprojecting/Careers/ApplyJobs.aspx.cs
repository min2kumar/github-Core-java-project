using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace WebApplication20
{
	/// <summary>
	/// Summary description for WebForm2.
	/// </summary>
	public partial class WebForm2 : System.Web.UI.Page
	{

		SqlConnection con=new SqlConnection("database=hrmsprj;server=.;uid=sa;");
	
		protected void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void btnUploadTheFile_ServerClick(object sender, System.EventArgs e)
		{
			
			string str;
			string filename;	 			
     		filename=System.IO.Path.GetFileName(uplTheFile.PostedFile.FileName);
			con.Open();
				str="insert into Resumes values('"+ TextBox1.Text +"','"+ TextBox2.Text +"',"+ TextBox3.Text +",'"+ filename +"','"+ DropDownList1.SelectedItem.Text +"')";
			    SqlCommand cmd=new SqlCommand(str,con);
			cmd.ExecuteNonQuery ();
 			TextBox1.Text="";
			TextBox2.Text="";
			TextBox3.Text="";
			con.Close();
		}

	}
}
