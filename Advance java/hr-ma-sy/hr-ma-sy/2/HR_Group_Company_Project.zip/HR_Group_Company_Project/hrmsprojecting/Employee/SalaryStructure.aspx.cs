using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace hrmsprojecting.Employee
{
	/// <summary>
	/// Summary description for SalaryDetail.
	/// </summary>
	public partial class SalaryDetail : System.Web.UI.Page
	{

        SqlConnection con = new SqlConnection("Data Source=APTTECH5;Initial Catalog=HRGroup;Integrated Security=True;");

		protected void Page_Load(object sender, System.EventArgs e)
		{

					
			con.Open();
			DataSet ds = new DataSet();
			string eid = Convert.ToString(Session["empid"]);
			SqlCommand cmd = new SqlCommand("Select Designation from Employee where EmployeeId='"+ eid +"'");
			cmd.Connection = con;
			cmd.ExecuteScalar();
			string designation = Convert.ToString(cmd.ExecuteScalar());
			SqlDataAdapter adp = new SqlDataAdapter("select * from SalaryStructure where Designation='"+ designation +"'",con);
			adp.Fill(ds);
			DataList1.DataSource = ds;
			DataList1.DataBind();
			con.Close();
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    

		}
		#endregion

		protected void DataList1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}
	}
}
